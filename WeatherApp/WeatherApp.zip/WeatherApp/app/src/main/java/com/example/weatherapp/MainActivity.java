package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);

        AsyncThread task = new AsyncThread();
        task.execute();

    }
    public class AsyncThread extends AsyncTask<Void, Void, Void>{
        @Override
        protected Void doInBackground(Void... voids) {

            try {

                URL url = new URL("http://api.openweathermap.org/geo/1.0/zip?zip=08810,US&appid=18935495ebcc99d0cf99ed51136f12c7");
                URLConnection urlConnection = url.openConnection();
                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String data ="";

                while(!bufferedReader.readLine().equals(null)) {
                    data += bufferedReader.read();
                }

                JSONObject jsonObject = new JSONObject();
                textView.setText(data);
                StringTokenizer stringTokenizer = new StringTokenizer(data, ",");
                try {
                    jsonObject.put("data points", data);
                }catch(JSONException e) {
                    e.printStackTrace();
                }

            } catch (MalformedURLException e) {
                throw new RuntimeException(e);

            } catch (IOException e) {
                throw new RuntimeException(e);
            }


            Log.d("TAG","Thread ");
            return null;
        }
    }
}

